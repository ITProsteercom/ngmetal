@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="col-md-6 col-md-offset-3">
                <h2 style="color: green">{{ $message }}</h2>
        </div>
    </div>
@endsection