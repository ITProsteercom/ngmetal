@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="col-md-6 col-md-offset-3">
                <h2>{{ $error }}</h2>
        </div>
    </div>
@endsection