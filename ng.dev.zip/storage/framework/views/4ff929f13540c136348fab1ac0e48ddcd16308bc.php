<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-6 col-md-offset-3">

            <h1>Applications</h1>

            <hr>

            <table class="table table-bordered table-hover ">
                <thead>
                    <th>№</th>
                    <th>Package ID</th>
                    <th>Purchase Date</th>
                    <th>Reason</th>
                    <th>Message</th>
                    <th>Files</th>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$k); ?></td>
                            <td>
                                <?php echo e($application->package_id); ?>

                            </td>
                            <td>
                                <?php echo e($application->sent_date); ?>

                            </td>
                            <td>
                                <?php echo e($application->reason_id); ?>

                            </td>
                            <td>
                                <?php echo e($application->message); ?>

                            </td>
                            <td>
                                Files
                            </td>
                            
                                

                                
                                    
                                        
                                    

                                    
                                        
                                    
                                

                                

                            
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>