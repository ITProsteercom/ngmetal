<?php if(count($errors) > 0): ?>
    
    <div class="form-group">
        <div class="alert alert-danger">
                
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p>
                	<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
                	<?php echo e($error); ?>

                </p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
        </div>  
    </div>

<?php endif; ?>