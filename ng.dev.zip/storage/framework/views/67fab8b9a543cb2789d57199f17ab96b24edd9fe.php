<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-md-6 col-md-offset-3">
            <div class="form-area">
                <form role="form" method="POST" action="/" name="application_form" enctype="multipart/form-data">

                    <?php echo e(csrf_field()); ?>


                    <br style="clear:both">

                    <h3 style="margin-bottom: 25px; text-align: center;">NG Metal</h3>

                    <?php echo $__env->make('layouts.errors.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <div class="form-group">
                        <input type="text" class="form-control" id="package_id" name="package_id" placeholder="Package ID" value="<?php echo e($query['p']); ?>" readonly required>
                        <input type="hidden" name="sent_date" value="<?php echo e($query['d']); ?>">
                    </div>

                    <div class="form-group">
                        <div class="row">

                            <label class="col-sm-6">Choose your appeal reason:</label>

                            <div class="col-sm-6">

                                <div class="dropdown pull-right">

                                    <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenuReasons" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                        <input type="hidden" name="reason_id" id="reason_id" value="<?php echo e($reasons[0]->id); ?>">
                                        <span class="selected"><?php echo e($reasons[0]->name); ?></span>
                                        <span class="caret"></span>
                                    </button>

                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuReasons">

                                        <?php $__currentLoopData = $reasons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reason): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href="#" data-reason-id="<?php echo e($reason->id); ?>"><?php echo e($reason->name); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <textarea class="form-control noresize" type="textarea" id="message" name="message" placeholder="Message" rows="4"></textarea>
                    </div>

                    <div class="form-group">
                        <input type="file" id="input-files" name="files[]" multiple data-show-upload="false" data-show-remove="false" required>
                    </div>

                    <button type="submit" id="submit" name="submit" class="btn btn-primary pull-right">Send</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>