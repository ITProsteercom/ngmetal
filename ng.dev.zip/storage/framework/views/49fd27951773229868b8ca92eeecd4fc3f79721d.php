<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-md-6 col-md-offset-3">
            <div class="form-area">
                <form role="form">
                    <br style="clear:both">
                    <h3 style="margin-bottom: 25px; text-align: center;">NG Metal</h3>
                    <div class="form-group">
                        <input type="text" class="form-control" id="package" name="package" placeholder="Номер пакування" disabled required>
                    </div>
                    <div class="form-group">
                        <div class="dropdown">
                            <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                Причина звернення
                                <span class="caret"></span>
                            </button>
                            <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                                <li><a href="#">Все добре</a></li>
                                <li><a href="#">Пошкоджена упаковка</a></li>
                                <li><a href="#">Пошкодженний вміст</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="form-group">
                        <textarea class="form-control" type="textarea" id="message" placeholder="Коментар" maxlength="140" rows="4"></textarea>
                    </div>
                    <div class="form-group">
                        <input type="file" multiple>
                    </div>

                    <button type="button" id="submit" name="submit" class="btn btn-primary pull-right">Відправити</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>