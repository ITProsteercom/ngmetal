<?php

namespace App\Http\Controllers;

use App\Application;
use Illuminate\Http\Request;

class PhotoController extends Controller
{
    
}
