<?php

namespace App;


class Reason extends Model
{
    
}
