<?php

namespace App;


class Photo extends Model
{

	protected $table = 'files';
    public $timestamps = false;

}
